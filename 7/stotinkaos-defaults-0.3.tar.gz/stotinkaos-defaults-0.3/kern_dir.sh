KERN_DIR=/usr/src/kernels/`uname -r`-`uname -m`
export KERN_DIR
